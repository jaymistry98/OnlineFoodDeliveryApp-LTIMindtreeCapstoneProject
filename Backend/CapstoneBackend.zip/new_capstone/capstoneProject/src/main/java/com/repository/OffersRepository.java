package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.entity.Offers;

public interface OffersRepository extends JpaRepository<Offers, Integer>{

}
